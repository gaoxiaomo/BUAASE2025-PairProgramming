// snake.ts
// 内存管理辅助函数
import { conv1_weights,conv1_biases,conv2_weights,conv2_biases,fc1_weights,fc2_biases,fc2_weights,fc1_biases } from './params';  // 导入 params 对象
export function __newArray(size: i32): Int32Array {
  return new Int32Array(size);
}

// 主决策函数
export function greedy_snake_step(
    n: i32,                // 棋盘大小
    snake: Int32Array,     // 自己的蛇身坐标（长度8）
    snake_num: i32,        // 其他蛇的数量
    other_snakes: Int32Array, // 其他蛇的坐标
    food_num: i32,         // 食物数量
    foods: Int32Array,     // 食物坐标
    round: i32             // 剩余回合数
): i32 {
  const gridSize = n;
  const observation = new StaticArray<f64>(3 * gridSize * gridSize);

  // 初始化观察数组为0
  for (let i = 0; i < observation.length; i++) {
    observation[i] = 0.0;
  }


  // 通道0：所有蛇的身体（标记为1）
  // 通道1：当前蛇头标记为2，其他蛇头标记为1
  // 通道2：食物标记为1

  // 填充自己的蛇身（如果存活）
  if (snake[0] != -1) { // 检查是否存活
    for (let i = 0; i < 8; i += 2) {
      const x = snake[i] - 1;
      const y = snake[i + 1] - 1;
      if (x >= 0 && y >= 0 && x < gridSize && y < gridSize) {
        const idx = 0 * gridSize * gridSize + y * gridSize + x
        observation[idx] = 1.0;
      }
    }
    // 标记自己的头部（通道1）
    const headX = snake[0] - 1;
    const headY = snake[1] - 1;
    if (headX >= 0 && headY >= 0 && headX < gridSize && headY < gridSize) {
      const idx = 1 * gridSize * gridSize + headY * gridSize + headX;
      observation[idx] = 2.0;
    }
  }

  // 填充其他蛇的身体和头部
  for (let s = 0; s < snake_num; s++) {
    const snakeOffset = s * 8;
    for (let i = 0; i < 8; i += 2) {
      const x = other_snakes[snakeOffset + i] - 1;
      const y = other_snakes[snakeOffset + i + 1] - 1;
      if (x >= 0 && y >= 0 && x < gridSize && y < gridSize) {
        // 通道0：身体
        const bodyIdx = 0 * gridSize * gridSize + y * gridSize + x;
        observation[bodyIdx] = 1.0;
      }
    }
    // 通道1：其他蛇头
    const otherHeadX = other_snakes[snakeOffset] - 1;
    const otherHeadY = other_snakes[snakeOffset + 1] - 1;
    if (otherHeadX >= 0 && otherHeadY >= 0 && otherHeadX < gridSize && otherHeadY < gridSize) {
      const headIdx = 1 * gridSize * gridSize + otherHeadY * gridSize + otherHeadX;
      observation[headIdx] = 1.0;
    }
  }

  // 填充食物（通道2）
  for (let f = 0; f < food_num * 2; f += 2) {
    const x = foods[f] - 1;
    const y = foods[f + 1] - 1;
    if (x >= 0 && y >= 0 && x < gridSize && y < gridSize) {
      const foodIdx = 2 * gridSize * gridSize + y * gridSize + x;
      observation[foodIdx] = 1.0;
    }
  }
  for (let j = 0; j < 3; j++) {
    console.log("Matrix " + j.toString() + ":");
    for (let s = 0; s < gridSize; s++) {
      let row = "";
      for (let k = 0; k < gridSize; k++) {
        let value = observation[j * gridSize * gridSize + s * gridSize + k];
        row += value.toString() + " ";
      }
      console.log(row);
    }
    console.log(""); // 空行，分隔不同矩阵
  }



  // 神经网络推理
  const model = new DQN();
  const output = model.forward(observation);
  console.log(output.toString());

  // 选择最大Q值的动作
  let maxQ = -Infinity;
  let bestAction: i32 = 0;
  for (let i: i32 = 0; i < 4; i++) {
    if (output[i] > maxQ) {
      maxQ = output[i];
      bestAction = i;
    }
  }

  return bestAction;
}

// 神经网络模型
class DQN {
  private conv1_weights: StaticArray<f64>;
  private conv1_biases: StaticArray<f64>;
  private conv2_weights: StaticArray<f64>;
  private conv2_biases: StaticArray<f64>;
  private fc1_weights: StaticArray<f64>;
  private fc1_biases: StaticArray<f64>;
  private fc2_weights: StaticArray<f64>;
  private fc2_biases: StaticArray<f64>;
  private flattenedSize: i32 = 0;

  constructor() {
    this.conv1_weights = new StaticArray<f64>(conv1_weights.length);
    this.conv1_biases = new StaticArray<f64>(conv1_biases.length);
    this.conv2_weights = new StaticArray<f64>(conv2_weights.length);
    this.conv2_biases = new StaticArray<f64>(conv2_biases.length);
    this.fc1_weights = new StaticArray<f64>(fc1_weights.length);
    this.fc1_biases = new StaticArray<f64>(fc1_biases.length);
    this.fc2_weights = new StaticArray<f64>(fc2_weights.length);
    this.fc2_biases = new StaticArray<f64>(fc2_biases.length);

    // 将参数从导入的数据填充到 StaticArray 中
    this.fillArray(this.conv1_weights, conv1_weights);
    this.fillArray(this.conv1_biases, conv1_biases);
    this.fillArray(this.conv2_weights, conv2_weights);
    this.fillArray(this.conv2_biases, conv2_biases);
    this.fillArray(this.fc1_weights, fc1_weights);
    this.fillArray(this.fc1_biases, fc1_biases);
    this.fillArray(this.fc2_weights, fc2_weights);
    this.fillArray(this.fc2_biases, fc2_biases);
  }

  private fillArray(arr: StaticArray<f64>, data: f64[]): void {
    for (let i = 0; i < arr.length; i++) {
      arr[i] = data[i];
    }
  }

  // private initializeParams(state: StaticArray<f64>): void {
  //   if (this.flattenedSize > 0) return;
  //
  //   // 动态计算输入尺寸
  //   const gridSize = Math.sqrt(state.length / 3) as i32;
  //   const inputShape: i32[] = [3, gridSize, gridSize];
  //
  //   // 计算卷积输出尺寸
  //   const conv1Out = this.calcConvOutput(inputShape, 3, 1);
  //   const conv2Out = this.calcConvOutput(conv1Out, 3, 1);
  //   this.flattenedSize = conv2Out[0] * conv2Out[1] * conv2Out[2];
  //
  //   // 初始化卷积层参数（示例使用全1）
  //   this.conv1_weights = new StaticArray<f64>(32 * 3 * 3 * 3);
  //   this.conv1_biases = new StaticArray<f64>(32);
  //   this.fillOnes(this.conv1_weights);
  //   this.fillOnes(this.conv1_biases);
  //
  //   this.conv2_weights = new StaticArray<f64>(64 * 32 * 3 * 3);
  //   this.conv2_biases = new StaticArray<f64>(64);
  //   this.fillOnes(this.conv2_weights);
  //   this.fillOnes(this.conv2_biases);
  //
  //   // 初始化全连接层参数
  //   this.fc1_weights = new StaticArray<f64>(256 * this.flattenedSize);
  //   this.fc1_biases = new StaticArray<f64>(256);
  //   this.fillOnes(this.fc1_weights);
  //   this.fillOnes(this.fc1_biases);
  //
  //   this.fc2_weights = new StaticArray<f64>(4 * 256);
  //   this.fc2_biases = new StaticArray<f64>(4);
  //   this.fillOnes(this.fc2_weights);
  //   this.fillOnes(this.fc2_biases);
  // }

  private calcConvOutput(
      inputShape: i32[],
      kernelSize: i32,
      stride: i32
  ): i32[] {
    const inC = inputShape[0];
    const inH = inputShape[1];
    const inW = inputShape[2];
    const outH = (inH - kernelSize) / stride + 1;
    const outW = (inW - kernelSize) / stride + 1;
    return [32, outH, outW]; // 第一层固定输出32通道
  }

  private fillOnes(arr: StaticArray<f64>): void {
    for (let i = 0; i < arr.length; i++) {
      arr[i] = 1.0;
    }
  }

  forward(state: StaticArray<f64>): StaticArray<f64> {
    // this.initializeParams(state);
    const gridSize = Math.sqrt(state.length / 3) as i32;

    // 第一层卷积
    let x = this.conv2d(
        state,
        [3, gridSize, gridSize],
        this.conv1_weights,
        this.conv1_biases,
        32, 3, 1
    );
    x = this.relu(x);

    // 第二层卷积
    const conv1OutShape = this.calcConvOutput([3, gridSize, gridSize], 3, 1);
    x = this.conv2d(
        x,
        conv1OutShape,
        this.conv2_weights,
        this.conv2_biases,
        64, 3, 1
    );
    x = this.relu(x);

    // 全连接层
    let fc = this.linear(x, this.fc1_weights, this.fc1_biases, this.flattenedSize, 256);
    fc = this.relu(fc);

    fc = this.linear(fc, this.fc2_weights, this.fc2_biases, 256, 4);

    return fc;
  }

  private conv2d(
      input: StaticArray<f64>,
      inShape: i32[],
      weights: StaticArray<f64>,
      biases: StaticArray<f64>,
      outChannels: i32,
      kernelSize: i32,
      stride: i32
  ): StaticArray<f64> {
    const inC = inShape[0];
    const inH = inShape[1];
    const inW = inShape[2];
    const outH = (inH - kernelSize) / stride + 1;
    const outW = (inW - kernelSize) / stride + 1;
    const output = new StaticArray<f64>(outChannels * outH * outW);

    for (let oc = 0; oc < outChannels; oc++) {
      for (let oh = 0; oh < outH; oh++) {
        for (let ow = 0; ow < outW; ow++) {
          let sum = 0.0;
          for (let ic = 0; ic < inC; ic++) {
            for (let kh = 0; kh < kernelSize; kh++) {
              for (let kw = 0; kw < kernelSize; kw++) {
                const ih = oh * stride + kh;
                const iw = ow * stride + kw;
                if (ih >= 0 && ih < inH && iw >= 0 && iw < inW) {
                  const inputIdx = ic * (inH * inW) + ih * inW + iw;
                  const weightIdx = oc * (inC * kernelSize * kernelSize) +
                      ic * (kernelSize * kernelSize) +
                      kh * kernelSize + kw;
                  sum += input[inputIdx] * weights[weightIdx];
                }
              }
            }
          }
          const outIdx = oc * (outH * outW) + oh * outW + ow;
          output[outIdx] = f32(sum) + (oc < biases.length ? biases[oc] : f32(0));
        }
      }
    }
    return output;
  }

  private relu(input: StaticArray<f64>): StaticArray<f64> {
    const output = new StaticArray<f64>(input.length);
    for (let i = 0; i < input.length; i++) {
      output[i] = max(input[i], 0.0);
    }
    return output;
  }

  private linear(
      input: StaticArray<f64>,
      weights: StaticArray<f64>,
      biases: StaticArray<f64>,
      inSize: i32,
      outSize: i32
  ): StaticArray<f64> {
    const output = new StaticArray<f64>(outSize);
    for (let i = 0; i < outSize; i++) {
      let sum = 0.0;
      for (let j = 0; j < inSize; j++) {
        sum += input[j] * weights[i * inSize + j];
      }
      output[i] = f32(sum) + (i < biases.length ? biases[i] : f32(0));
    }
    return output;
  }
}